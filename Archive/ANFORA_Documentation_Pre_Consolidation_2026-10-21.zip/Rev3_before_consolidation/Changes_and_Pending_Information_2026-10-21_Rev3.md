# ANFORA Innovator Indicators - Revision 3

Review date: 21 October 2026. Period: 1 March-31 August 2026.
Status: internal review and preparation of a response to Lasith; no formal RURACTIVE approval.

## Changes from Rev2

- NBS15.1: entered declared 0 persons trained, confirmed by the Evenor-Tech responsible; not independently validated or signed certification.
- RRTG.SC-01b: entered declared 0 eligible external citizen-engagement participants. The 5 August stakeholder meeting is excluded from the count. Its minutes explicitly describe a demonstration to external representatives: this literal discrepancy is retained, and the eligibility/classification requires written clarification with Evenor-Tech and Lasith. The minutes are not proof of zero attendance.
- NBS24.18: entered declared 0 attributable new jobs for March-August only. The official annual window and final annual outcome remain open; # jobs and the FTE target are preserved.
- Located and verified three PostHog CSVs: daily sums 1, 4 and 39, all on 31 August. The responsible identifies the metrics as one unique identity, four unique Pageview sessions and 39 pageviews, and confirms they are his internal tests. The CSVs omit aggregation settings, project, timezone, filters and identity/session IDs. Raw files are preserved with hashes.
- INNOV_003 external users/sessions remain unavailable. Do not infer zero external visits from zero bins without demonstrated capture coverage. The two anonymous MongoDB calculations retain separate unverified provenance.
- The 48-person statement is now attributed internally to September/October training. Excluded from March-August; no certified event breakdown and no addition to the approximate ADA ITS attendance.
- NBS4.20, INNOV_002 and INNOV_004 remain Not measured. Municipal 2024 water figures are contextual, not WEI+ or ANFORA impact; no irrigation electricity/ha measurements or verified historical paired footprint comparison exists.
- INNOV_005 and INNOV_006 remain Not assessable: no period numerical satisfaction surveys or sufficient demographic data. No scores, shares or alert states are inferred.
- All nine delivery routes and auto_accept fields remain unassigned/blank. No provisional all-DMS configuration has been reinstated.
- Preserved official definitions, units, targets, baselines and time fields. E15 remains verified; the meeting's exact calendar date is not invented.

## Evidence classification

The three zeros are responsible-party declarations supplied for this revision (E22), not signed certificates or independently reconciled measurements. The PostHog CSV values/dates are directly checked (E23-E25); metric mapping and tester identity derive from the responsible's confirmation. The historical MongoDB aggregates remain the separate read-only evidence from Rev2, without a new query.

## Remaining actions

### P01 Corroboration of declared zeros

Evenor-Tech: retain an accountable written declaration for each zero and period, reconcile activity calendar and HR records; clarify the literal demonstration in the 5 August stakeholder minutes. No certificate or signature has been supplied.

Impact: NBS15.1 and RRTG.SC-01b declared 0; NBS24.18 declared period 0, annual result open. Sources: E06 E13 E22.

### P02 Per-code delivery agreement

Lasith: confirm API/AMT/DMS terminology, mechanism for each of nine codes, auto_accept semantics, missing-value representation, receiver fields/schema and receipt requirements.

Impact: All nine routes and auto_accept remain unassigned/blank; no submission or integration is approved. Sources: E01 E15.

### P03 Activity eligibility and target mapping

Lasith: confirm citizen-activity eligibility, exclusion of coordination demonstrations, participants versus 100 registered users and repeat-attendance rule. Evenor-Tech: retain event classification reconciliation.

Impact: Do not calculate participant target achievement or certify the zero as independently measured. Sources: E01 E06 E22.

### P04 Analytics settings coverage and independent record provenance

Evenor-Tech analytics owner: retain saved insight settings/screenshots, project/timezone/filter/aggregation details and historical deployment/consent/retention evidence. Confirm internal test exclusion. Investigate the two anonymous MongoDB records independently.

Impact: Internal PostHog observations supported; full-period external users/sessions remain unavailable. Sources: E10 E11 E12 E22 E23 E24 E25.

### P05 Water and historical comparison definitions

Lasith: clarify NBS4.20 ratio/target mapping and INNOV_004 aggregation, simulated versus observed outcomes. Evenor-Tech: matched territorial water data or valid dated paired footprint scenarios if they exist.

Impact: NBS4.20 and INNOV_004 remain Not measured; municipal 2024 volumes are context only. Sources: E01 E17 E22.

### P06 Annual employment and irrigation window

Lasith: confirm annual employment observation boundaries and jobs/FTE interpretation. Evenor-Tech HR: annual corroboration; farm partners: electricity/area and seasonal references.

Impact: Declared job zero applies only to March-August; INNOV_002 remains Not measured. Sources: E01 E13 E22.

### P07 Unavailable survey and demographic results

Lasith: agree missing-data encoding, satisfaction denominator/coding, demographic denominator/group overlap and window treatment. Evenor-Tech: document absence of period surveys and sufficient demographic records; design future collection separately.

Impact: INNOV_005 and INNOV_006 remain Not assessable; no numerical zeros or Boolean alert conclusions. Sources: E01 E13 E22.

### P08 September/October training figure

Evenor-Tech/Francisco: original event dates and attendance/completion records before certifying or breaking down the 48-person statement. Internal clarification places it in September/October, outside this period.

Impact: Exclude 48 from March-August; do not add it to approximate ADA ITS attendance or calculate unverified subtotals. Sources: E08 E14 E15 E22.

## Deliverables and preservation

Updated the Word report, matching PDF, official Innovator Indicators method workbook, period Data Collection workbook, traceability matrix and this note. Retained one active Rev3 package and a byte-verified six-file Rev2 ZIP backup. Preserved three raw CSV evidence copies unchanged. Original reports, annexes, transcript and project evidence are not overwritten. No application, database, credentials, configuration, deployment or Git history was changed.
